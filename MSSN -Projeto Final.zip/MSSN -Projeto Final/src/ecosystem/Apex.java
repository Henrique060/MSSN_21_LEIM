package ecosystem;

import java.util.ArrayList;
import java.util.List;

import aaa.Eye;
import physics.Body;
import processing.core.PApplet;
import processing.core.PImage;
import processing.core.PVector;
import tools.SubPlot;

public class Apex extends Animal{

    private final PApplet p;
    private final SubPlot plt;
    private PImage img;
    public Apex(PVector pos, float mass, float radius, int color, PApplet p, SubPlot plt, PImage img) {
        super(pos, mass, radius, color, p, plt, img);
        this.p = p;
        this.plt = plt;
        energy = WorldConstants.INI_APEX_ENERGY;
    }

    public Apex(Apex apex, Boolean mutate, PApplet p, SubPlot plt, PImage img){
        super(apex, mutate, p, plt,"Apex", img);
        this.p = p;
        this.plt = plt;
        this.img = img;
        energy = WorldConstants.INI_APEX_ENERGY;
    }

    @Override
    public Animal reproduce(boolean mutate) {
        Animal child = null;
        if(energy > WorldConstants.APEX_ENERGY_TO_REPRODUCE) {
            energy -= WorldConstants.INI_APEX_ENERGY;
            child = new Apex(this, mutate, p, plt, img);
            if (mutate) child.mutateBehaviors();
        }
        return child;
    }

    @Override
    public void eat(Terrain terrain) {
        // TODO Auto-generated method stub

    }

    @Override
    public List<Animal> eat (List<Animal> animals){
        PVector mePos = this.getPos().copy();

        for(Animal animal : animals){
            if(animal instanceof Predator){
                PVector preyPos = animal.getPos().copy();
                float distance = PVector.dist(mePos, preyPos);
                if(distance < this.radius*5){
                    energy += WorldConstants.APEX_ENERGY_FROM_PREDATOR;
                    animals.remove(animal);
                    return animals;
                }
            }
            if(animal instanceof Prey){
                PVector preyPos = animal.getPos().copy();
                float distance = PVector.dist(mePos, preyPos);
                if(distance < this.radius*5){
                    energy += WorldConstants.APEX_ENERGY_FROM_PREY;
                    animals.remove(animal);
                    return animals;
                }
            }
        }
        return animals;
    }

    public void updateTargetPrey(PApplet p, List<Body> obstacles, List<Animal> allPrey) {
        float dist = 0;
        if (!obstacles.contains(this.target) && this.target != null) {
            //distancia entre o animal e a prey
            dist = PVector.dist(this.getPos(), this.target.getPos());
            if (dist > this.getDNA().visionSafeDistance) {
                for (Animal animal : allPrey) {
                    float newDist = PVector.dist(this.getPos(), animal.getPos());
                    if (newDist < dist && this.target != animal && animal instanceof Predator) {
                        this.target = animal;
                    }
                }
                List<Body> tempTrackingBodies = new ArrayList<>();
                //adicionar o target e obstaculos a lista
                tempTrackingBodies.add(this.target);
                tempTrackingBodies.addAll(obstacles);
                //criar um novo Eye com essa lista
                Eye eye = new Eye(this, tempTrackingBodies);
                this.setEye(eye);
            }
        }
    }

}
