import processing.core.PApplet;

public interface iZOOG {
    void settings(PApplet parent);
    void setup(PApplet parent);
    void draw(PApplet parent, float ft);
}
